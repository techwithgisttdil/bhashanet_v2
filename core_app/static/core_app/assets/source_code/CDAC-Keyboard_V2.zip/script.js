
StartMe();
let currSite ="";

// call the method when new page completely opens

chrome.webNavigation.onCompleted.addListener(StartMe);
// try this as history / back button is not having websites
//chrome.webNavigation.onHistoryStateUpdated

async function StartMe()
{
	
	// set the event listners for buttons on ui	
	await document.getElementById("Go").addEventListener("click", GoExe);
	await document.getElementById("fxkbd").addEventListener("click", ShowMyKeyboard);

	var urlname = "";
	
	// get the domain url of page in current / active tab 
	
	let queryOptions = { active: true, currentWindow: true };
	// `tab` will either be a `tabs.Tab` instance or `undefined`.
	let [tab] = await chrome.tabs.query(queryOptions);
	
	if (!tab) alert('undef');
	//alert(tab.url.split("/")[2]);
	urlname= tab.url.split("/")[2];
	
	
	urlname = punycode.toUnicode(urlname);
	
	if (urlname.includes("www."))
		urlname = urlname.substring(4);
		
	//alert (u);
	
	
	//alert (toUnicode(urlname));
	//urlname = toUnicode(urlname);
    /*(const tempURL = new URL('https://सीडैक.भारत/index.aspx?id=about');
	alert (tempURL.origin);
	alert (tempURL.hostname);
	alert (tempURL.href);
	alert (tempURL.host);
	*/
	//const u = await tempURL.createObjectURL();
	//alert(u.toString());
	
	
	//alert (encodeURIComponent ('https://सीडैक.भारत/index.aspx?id=about'));
	
	
	//urlname = location.hostname; //location.hostname;
	//location.hostname = "example.com";
	// handling for new tabs / others 
	/*if (urlname <> "newTab")
	 document.getElementById("BigBox").value = urlname;
	else
	  document.getElementById("BigBox").value = "T";
     */
	
   currSite = urlname;
   // set the text in the edit box
   document.getElementById("BigBox").value = urlname;
   // set focus to the edit box
   await document.getElementById("BigBox").focus();
   //alert(urlname);
   //alert(encodeURIComponent(urlname));
}

async function GoExe() {
	
	//set current tab in history ?
	// get current tab
	let queryOptions = { active: true, currentWindow: true };
	// `tab` will either be a `tabs.Tab` instance or `undefined`.
	let [tab] = await chrome.tabs.query(queryOptions);
	//alert(tab.url.split("/")[2]);
	//tab.url = newURL;
	
	//chrome.history.addUrl({url: "https://mozilla.com"});
	
	// get the text from edit box	
	let BoxDataString =  await document.getElementById("BigBox").value;
	
	// append https if not present
	// without protocol navigation was not happening properly
	let newURL = "https://"; 
	
	if (BoxDataString.includes("https://"))		
		newURL =  BoxDataString;
	else
		newURL =  newURL + BoxDataString;
			

	
	//chrome.tabs.update(undefined, { url: "https://example.com" });
	
	// update the content on the tab
	// but not getting reflecing in history or back-button
	await chrome.tabs.update(undefined, { url: newURL });
	currSite = newURL;
	//document.getElementById("BigBox").value = newURL;
	//alert(currSite);
}


async function ShowMyKeyboard()
{
	// if keyboard is open then close it
	closeKeyboard();
	// open non moveable keyboard with Hindi as default
    openKeyboard( 'Hindi',null,'kbdContr');
	//set focus so that typing can start immediately
	document.getElementById("BigBox").focus();
	
}